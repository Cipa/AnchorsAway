<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Use at your own risk. No guarantees provided ;)',
    'readme' => 'Anchors Away Plugin for MODX Revolution 
Thanks to BobRay and OpenGeek

Properties
	
	onTemplates [Texfield] [Comma separated list of template IDs] - property to specify the templates you want to run this plugin on

System Events (please check)

	OnWebPagePrerender',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '90854a087356cca823bd131169c37052',
      'native_key' => 'anchorsaway',
      'filename' => 'modNamespace/66d5322ce66fe585f028d59e64be4fe3.vehicle',
      'namespace' => 'anchorsaway',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '3169692d659d011ce51b80447ee9e782',
      'native_key' => 6,
      'filename' => 'modPlugin/1641ca9a22a0f22c42f484cd60339e42.vehicle',
      'namespace' => 'anchorsaway',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3ae55147782f980618f9c15340e98fdb',
      'native_key' => 1,
      'filename' => 'modCategory/178e1c046ac9945c239ef38c24733f5a.vehicle',
      'namespace' => 'anchorsaway',
    ),
  ),
);